OS X Quick Look plugin for IFF ILBM images
Version 1.0 Beta (March 22, 2013)

Supported IFF-features:

* ILBM and PBM
* 1-8 bitplanes
* Extra halfbrite
* Hold and modify
* Transparency

Coded by David Revelj
Please send bug reports and non-working IFF files to dalton@tulou.org

Be cool, stay in school!